package com.example.watchtogether.model;

public class ChatMessage {
    public enum Type { CHAT, JOIN, LEAVE, TYPING }

    private Type type;
    private String roomId;
    private String sender;
    private String content;

    public Type getType() { return type; }
    public void setType(Type type) { this.type = type; }
    public String getRoomId() { return roomId; }
    public void setRoomId(String roomId) { this.roomId = roomId; }
    public String getSender() { return sender; }
    public void setSender(String sender) { this.sender = sender; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
}
