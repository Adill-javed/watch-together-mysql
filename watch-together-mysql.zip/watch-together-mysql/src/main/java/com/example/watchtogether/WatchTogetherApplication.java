package com.example.watchtogether;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WatchTogetherApplication {
    public static void main(String[] args) {
        SpringApplication.run(WatchTogetherApplication.class, args);
    }
}
